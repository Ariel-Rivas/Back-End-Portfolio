package com.Portfolio.Ariel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArielApplicationTests {

	@Test
	void contextLoads() {
	}

}
